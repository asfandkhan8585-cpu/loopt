import React from 'react';
import ReactDOM from 'react-dom/client';
import Loopt from './Loopt';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Loopt />
  </React.StrictMode>
);
