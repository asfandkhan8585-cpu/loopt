import React, { useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, ArrowUpRight, ArrowDownLeft, LogOut, Eye, EyeOff } from 'lucide-react';

const Loopt = () => {
  const [userRole, setUserRole] = useState(null);
  const [showBalance, setShowBalance] = useState(true);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [transactionType, setTransactionType] = useState('credit');

  const [balance, setBalance] = useState(100000);
  const [transactions, setTransactions] = useState([]);

  const [newTransaction, setNewTransaction] = useState({
    amount: '',
    description: ''
  });

  const handleLogin = () => {
    const username = loginForm.username.trim().toLowerCase();
    const password = loginForm.password.trim();

    if (username === 'owner' && password === 'owner123') {
      setUserRole('owner');
    } else if (username === 'employee' && password === 'employee123') {
      setUserRole('employee');
    } else {
      alert('Invalid credentials. Please check username and password.');
    }
  };

  const handleLogout = () => {
    setUserRole(null);
    setLoginForm({ username: '', password: '' });
  };

  const handleAddTransaction = () => {
    if (!newTransaction.amount || !newTransaction.description) {
      alert('Please fill all fields');
      return;
    }

    const amount = parseFloat(newTransaction.amount);

    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    const now = new Date();
    const newTxn = {
      id: Date.now(),
      type: transactionType,
      amount: amount,
      description: newTransaction.description,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
      status: 'completed'
    };

    setTransactions([newTxn, ...transactions]);

    if (transactionType === 'credit') {
      setBalance(prevBalance => prevBalance + amount);
    } else {
      setBalance(prevBalance => prevBalance - amount);
    }

    setNewTransaction({ amount: '', description: '' });
    setShowTransactionModal(false);
  };

  const totalCredit = transactions.filter(t => t.type === 'credit').reduce((sum, t) => sum + t.amount, 0);
  const totalDebit = transactions.filter(t => t.type === 'debit').reduce((sum, t) => sum + t.amount, 0);

  if (!userRole) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
        <div className="bg-slate-800/50 backdrop-blur-lg border border-orange-500/20 rounded-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="bg-orange-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 orange-glow">
              <span className="text-white font-extrabold text-2xl">L</span>
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Loopt</h1>
            <p className="text-orange-300">Sign in to your account</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-orange-300 text-sm mb-2">Username</label>
              <input
                type="text"
                value={loginForm.username}
                onChange={(e) => setLoginForm({...loginForm, username: e.target.value})}
                className="w-full px-4 py-3 bg-slate-700 border border-orange-500/30 rounded-lg text-white focus:outline-none focus:border-orange-500"
                placeholder="Enter username"
              />
            </div>
            <div>
              <label className="block text-orange-300 text-sm mb-2">Password</label>
              <input
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                className="w-full px-4 py-3 bg-slate-700 border border-orange-500/30 rounded-lg text-white focus:outline-none focus:border-orange-500"
                placeholder="Enter password"
              />
            </div>
            <button
              onClick={handleLogin}
              className="w-full py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition font-semibold"
            >
              Sign In
            </button>
          </div>

          <div className="mt-6 p-4 bg-slate-700/50 rounded-lg">
            <p className="text-orange-300 text-sm mb-2">Demo Credentials:</p>
            <p className="text-white text-xs">Owner: owner / owner123</p>
            <p className="text-white text-xs">Employee: employee / employee123</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <header className="bg-slate-900/50 backdrop-blur-lg border-b border-orange-500/20">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-orange-500 p-2 rounded-lg">
                <span className="text-white font-bold">L</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Loopt</h1>
                <p className="text-orange-300 text-sm capitalize">{userRole} Account</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {userRole === 'owner' && (
          <div className="bg-slate-800/50 backdrop-blur-lg border border-orange-500/20 rounded-xl p-6 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-300 text-sm mb-2">Current Balance</p>
                <div className="flex items-center gap-4">
                  {showBalance ? (
                    <p className="text-4xl font-bold text-white">
                      Rs. {balance.toLocaleString('en-PK', { minimumFractionDigits: 2 })}
                    </p>
                  ) : (
                    <p className="text-4xl font-bold text-white">••••••••</p>
                  )}
                  <button
                    onClick={() => setShowBalance(!showBalance)}
                    className="text-orange-300 hover:text-orange-400 transition"
                  >
                    {showBalance ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
              <button
                onClick={() => setShowTransactionModal(true)}
                className="px-6 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition font-semibold"
              >
                New Transaction
              </button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-slate-800/50 backdrop-blur-lg border border-orange-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-orange-300 text-sm">Total Credits</p>
              <ArrowDownLeft className="w-5 h-5 text-green-400" />
            </div>
            <p className="text-3xl font-bold text-white">Rs. {totalCredit.toLocaleString('en-PK')}</p>
            <p className="text-green-400 text-sm mt-2">Money In</p>
          </div>

          <div className="bg-slate-800/50 backdrop-blur-lg border border-orange-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <p className="text-orange-300 text-sm">Total Debits</p>
              <ArrowUpRight className="w-5 h-5 text-red-400" />
            </div>
            <p className="text-3xl font-bold text-white">Rs. {totalDebit.toLocaleString('en-PK')}</p>
            <p className="text-red-400 text-sm mt-2">Money Out</p>
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-lg border border-orange-500/20 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-6">Recent Transactions</h2>

          <div className="space-y-3">
            {transactions.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-orange-300 text-lg">No transactions yet</p>
                <p className="text-slate-400 text-sm mt-2">Start by adding your first transaction</p>
              </div>
            ) : (
              transactions.map((txn) => (
              <div
                key={txn.id}
                className="bg-slate-700/50 rounded-lg p-4 hover:bg-slate-700/70 transition"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-full ${
                      txn.type === 'credit' ? 'bg-green-500/20' : 'bg-red-500/20'
                    }`}>
                      {txn.type === 'credit' ? (
                        <ArrowDownLeft className="w-5 h-5 text-green-400" />
                      ) : (
                        <ArrowUpRight className="w-5 h-5 text-red-400" />
                      )}
                    </div>
                    <div>
                      <p className="text-white font-medium">{txn.description}</p>
                      <p className="text-orange-300 text-sm">{txn.date} at {txn.time}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-xl font-bold ${
                      txn.type === 'credit' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {txn.type === 'credit' ? '+' : '-'}Rs. {txn.amount.toLocaleString('en-PK')}
                    </p>
                    <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                      {txn.status}
                    </span>
                  </div>
                </div>
              </div>
            ))
            )}
          </div>
        </div>
      </div>

      {showTransactionModal && userRole === 'owner' && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-800 border border-orange-500/20 rounded-2xl p-6 w-full max-w-md">
            <h3 className="text-2xl font-bold text-white mb-6">New Transaction</h3>

            <div className="space-y-4">
              <div>
                <label className="block text-orange-300 text-sm mb-2">Transaction Type</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setTransactionType('credit')}
                    className={`py-3 rounded-lg transition font-semibold ${
                      transactionType === 'credit'
                        ? 'bg-green-500 text-white'
                        : 'bg-slate-700 text-orange-300 hover:bg-slate-600'
                    }`}
                  >
                    Credit (Money In)
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransactionType('debit')}
                    className={`py-3 rounded-lg transition font-semibold ${
                      transactionType === 'debit'
                        ? 'bg-red-500 text-white'
                        : 'bg-slate-700 text-orange-300 hover:bg-slate-600'
                    }`}
                  >
                    Debit (Money Out)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-orange-300 text-sm mb-2">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={newTransaction.amount}
                  onChange={(e) => setNewTransaction({...newTransaction, amount: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-700 border border-orange-500/30 rounded-lg text-white focus:outline-none focus:border-orange-500"
                  placeholder="0.00"
                />
              </div>

              <div>
                <label className="block text-orange-300 text-sm mb-2">Description</label>
                <input
                  type="text"
                  value={newTransaction.description}
                  onChange={(e) => setNewTransaction({...newTransaction, description: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-700 border border-orange-500/30 rounded-lg text-white focus:outline-none focus:border-orange-500"
                  placeholder="Enter description"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowTransactionModal(false);
                    setNewTransaction({ amount: '', description: '' });
                  }}
                  className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleAddTransaction}
                  className="flex-1 py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-lg transition font-semibold"
                >
                  Add Transaction
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Loopt;
